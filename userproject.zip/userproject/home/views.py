from multiprocessing import context
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login,logout
from datetime import datetime
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# Create your views here.
# def 

def index(request):
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request,'index.html')

def loginUser(request):
    print("hello")
    print(request.method)
    if request.method == "POST":
        print("Hello world")
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        print(username,password)
        print(user)
        login(request,user)

        if user is not None:
            return redirect("/")
            # A backend authenticated the credentials
        else:
            return render(request,'login.html')
            # No backend authenticated the credentials
    return render(request,'login.html')

def logoutUser(request):
    logout(request)
    return redirect('/login')
def about(request):
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request,'about.html')

def services(request):
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request,'services.html')
# Create your views here.
def contact(request):
    if request.user.is_anonymous:
        return redirect("/login")
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name,email=email,phone=phone,desc=desc,date=datetime.today())
        contact.save()
        messages.success(request, 'Your Message has been sent.')

    return render(request,'contact.html')

def signup(request):
    form = UserCreationForm()
    if request.method == "POST":
        username = request.POST.get('usernamer')
        psw = request.POST.get('pswr')
        email = request.POST.get('email')
        user = User.objects.create_user(username=username,
                                 email=email,
                                 password=psw)
        user.save()
        return redirect("/login")

    # context = {'form':form}
    return render(request,'signup.html')